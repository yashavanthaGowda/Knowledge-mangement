### karnataka-assembly-elections-2018
